#!/bin/bash
# clocks.sh

# written by t-mo_


if [[ "$1" = 00 ]]
then
echo "A"
elif [[ $1 = 01 ]]
then
echo "B"
elif [[ $1 = 02 ]]
then
echo "C"
elif [[ $1 = 03 ]]
then
echo "D"
elif [[ $1 = 04 ]]
then
echo "E"
elif [[ $1 = 05 ]]
then
echo "F"
elif [[ $1 = 06 ]]
then
echo "G"
elif [[ $1 = 07 ]]
then
echo "H"
elif [[ $1 = 08 ]]
then
echo "I"
elif [[ $1 = 09 ]]
then
echo "J"
elif [[ $1 = 10 ]]
then
echo "K"
elif [[ $1 = 11 ]]
then
echo "L"
elif [[ $1 = 12 ]]
then
echo "M"
elif [[ $1 = 13 ]]
then
echo "N"
elif [[ $1 = 14 ]]
then
echo "O"
elif [[ $1 = 15 ]]
then
echo "P"
elif [[ $1 = 16 ]]
then
echo "Q"
elif [[ $1 = 17 ]]
then
echo "R"
elif [[ $1 = 18 ]]
then
echo "S"
elif [[ $1 = 19 ]]
then
echo "T"
elif [[ $1 = 20 ]]
then
echo "U"
elif [[ $1 = 21 ]]
then
echo "V"
elif [[ $1 = 22 ]]
then
echo "W"
elif [[ $1 = 23 ]]
then
echo "X"
elif [[ $1 = 24 ]]
then
echo "Y"
elif [[ $1 = 25 ]]
then
echo "Z"
elif [[ $1 = 26 ]]
then
echo "a"
elif [[ $1 = 27 ]]
then
echo "b"
elif [[ $1 = 28 ]]
then
echo "c"
elif [[ $1 = 29 ]]
then
echo "d"
elif [[ $1 = 30 ]]
then
echo "e"
elif [[ $1 = 31 ]]
then
echo "f"
elif [[ $1 = 32 ]]
then
echo "g"
elif [[ $1 = 33 ]]
then
echo "h"
elif [[ $1 = 34 ]]
then
echo "i"
elif [[ $1 = 35 ]]
then
echo "j"
elif [[ $1 = 36 ]]
then
echo "k"
elif [[ $1 = 37 ]]
then
echo "l"
elif [[ $1 = 38 ]]
then
echo "m"
elif [[ $1 = 39 ]]
then
echo "n"
elif [[ $1 = 40 ]]
then
echo "o"
elif [[ $1 = 41 ]]
then
echo "p"
elif [[ $1 = 42 ]]
then
echo "q"
elif [[ $1 = 43 ]]
then
echo "r"
elif [[ $1 = 44 ]]
then
echo "s"
elif [[ $1 = 45 ]]
then
echo "t"
elif [[ $1 = 46 ]]
then
echo "u"
elif [[ $1 = 47 ]]
then
echo "v"
elif [[ $1 = 48 ]]
then
echo "w"
elif [[ $1 = 49 ]]
then
echo "x"
elif [[ $1 = 50 ]]
then
echo "y"
elif [[ $1 = 51 ]]
then
echo "z"
elif [[ $1 = 52 ]]
then
echo "1"
elif [[ $1 = 53 ]]
then
echo "2"
elif [[ $1 = 54 ]]
then
echo "3"
elif [[ $1 = 55 ]]
then
echo "4"
elif [[ $1 = 56 ]]
then
echo "5"
elif [[ $1 = 57 ]]
then
echo "6"
elif [[ $1 = 58 ]]
then
echo "7"
elif [[ $1 = 59 ]]
then
echo "8"

fi

exit 0
