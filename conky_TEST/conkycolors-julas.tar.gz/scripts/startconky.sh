#!/bin/bash
caminho='~/.conkycolors/scripts'

conky $caminho/fundo 1>> cnk.log &
conky $caminho/network 1>> cnk.log &
conky $caminho/discos 1>> cnk.log &
conky $caminho/hardware 1>> cnk.log &
conky $caminho/procs 1>> cnk.log &
conky $caminho/software 1>> cnk.log &
conky $caminho/timeweather 1>> cnk.log &
